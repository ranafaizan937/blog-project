---
title: New One
slug: new-one-testing
date: 2024-12-09T16:22:58.751Z
imageUrl: /uploads/download.jpg
category: Tips & Advies
author: Team Schildersbedrijf040
excerpt: This one is for testing
content: >-
  **W﻿ho is Ricky Ponting**


  Ricky Thomas Ponting AO is an Australian cricket coach, commentator and former player. He was widely regarded as one of the greatest batsmen of all time and is the most successful captain in international cricket history, with 220 victories in 324 matches with a winning rate of 67.91%.\

  \

  **Career:**


  Ponting's domestic performances were rewarded when he was selected for the Australian ODI team to play in all the matches in the 1995 New Zealand Centenary quadrangular tournament in New Zealand, that also included South Africa and India. Ponting made his debut against [South Africa](https://en.wikipedia.org/wiki/South_Africa_national_cricket_team "South Africa national cricket team") at number six in the batting order. He scored one from six balls, as Australia successfully chased South Africa's target on a difficult batting track. Australia secured another victory in their next match, this time against [New Zealand](https://en.wikipedia.org/wiki/New_Zealand_national_cricket_team "New Zealand national cricket team") in Auckland, where Ponting scored 10 not out, after coming to wicket late in the innings. His highest series score came in the third International where Australia lost to [India](https://en.wikipedia.org/wiki/India_national_cricket_team "India national cricket team") in Dunedin. Ponting was promoted to number three in the batting order and responded by scoring 62 from 92 balls. The innings was scored without a boundary and was based on "deft placement and judicious running."[\[52]](https://en.wikipedia.org/wiki/Ricky_Ponting#cite_note-Ponting45-52) The loss failed to stop Australia from appearing in the final against New Zealand in Auckland. Ponting returned to number six and was seven not out when the winning runs were scored.[\[53]](https://en.wikipedia.org/wiki/Ricky_Ponting#cite_note-Ponting44-45-53) He finished the series with 80 runs at 40 and strike rate of 71.42 runs per hundred balls
metatitle: New one blog | MELAW
description: |
  this is gonna be the best one for testing
---
