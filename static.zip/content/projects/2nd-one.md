---
title: 2nd one
location: London
type: Buitenschilderwerk
beforeImage: /uploads/wallpaperflare.com_wallpaper.jpg
afterImage: /uploads/wallpaperflare.com_wallpaper.jpg
completionDate: 10/12/2024
projectManager: Done
description: This is the 2nd one for testing
workPerformed:
  - EverythingDone
materialsUsed:
  - All
result: The overall result was very awesome
---
