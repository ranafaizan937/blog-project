---
title: New Project
location: Faisalabad
type: Lakwerk
beforeImage: /uploads/download.jpg
afterImage: /uploads/download.jpg
completionDate: "2024"
projectManager: This is done
description: This is going to be good
workPerformed:
  - All
materialsUsed:
  - Metal
result: Nothing
---
